<?php 

//@UTF-8 castle_admin_menu.php
/*
 * Castle: KISA Web Attack Defender - PHP Version
 * 
 * Author : 이재서 <mirr1004@gmail.com>
 *          주필환 <juluxer@gmail.com>
 *
 * Last modified Sep 18 2008
 *
 */
?>
                <table width="100%" height="100%" cellspacing="0" cellpadding="0" border="0">
                  <tr>
                    <td width="100%" height="25">
                      <table width="160" height="100%" cellspacing="0" cellpadding="0" border="0">
                        <tr>
                          <td width="9" height="25"><img src="img/menu_top_lt.gif"></td>
                          <td width="143" height="25" background="img/menu_top_bg.gif" align="center"><img src="img/menu_top.gif"></td>
                          <td width="8" height="25"><img src="img/menu_top_rt.gif"></td>
                        </tr>
                      </table>
                    </td>
                  </tr>
                  <tr>
                    <td height="5"></td>
                  </tr>
                  <tr>
                    <th height="25" background="img/menu_bg.gif">
                      <a href="castle_admin.php"><font color="#D0D0D0">HOME</font></a>
                    </th>
                  </tr>
                  <tr>
                    <td height="1" background="img/line_bg.gif"></td>
                  </tr>
                  <tr>
                    <th height="25" background="img/menu_bg.gif">
                      <a href="castle_admin_account.php"><font color="#D0D0D0">계정설정</font></a>
                    </th>
                  </tr>
                  <tr>
                    <td height="1" background="img/line_bg.gif"></td>
                  </tr>
                  <tr>
                    <th height="25" background="img/menu_bg.gif">
                      <a href="castle_admin_config.php"><font color="#D0D0D0">기본설정</font></a>
                    </th>
                  </tr>
                  <tr>
                    <th height="25" background="img/menu_bg.gif">
                      <a href="castle_admin_policy.php"><font color="#D0D0D0">정책설정</font></a>
                    </th>
                  </tr>
                  <tr>
                    <th height="25" background="img/menu_bg.gif">
                      <a href="castle_admin_advance.php"><font color="#D0D0D0">고급설정</font></a>
                    </th>
                  </tr>
                  <tr>
                    <td height="1" background="img/line_bg.gif"></td>
                  </tr>
                  <tr>
                    <th height="25" background="img/menu_bg.gif">
                      <a href="castle_admin_log.php"><font color="#D0D0D0">로그관리</font></a>
                    </th>
                  </tr>
                  <tr>
                    <th height="25" background="img/menu_bg.gif">
                      <a href="castle_admin_policy_view.php"><font color="#D0D0D0">정책보기</font></a>
                    </th>
                  </tr>
                  <tr>
                    <th height="25" background="img/menu_bg.gif">
                      <a href="castle_admin_backup.php"><font color="#D0D0D0">백업관리</font></a>
                    </th>
                  </tr>
                  <tr valign="top">
                    <td width="100%">
                    </td>
                  </tr>
                </table>
