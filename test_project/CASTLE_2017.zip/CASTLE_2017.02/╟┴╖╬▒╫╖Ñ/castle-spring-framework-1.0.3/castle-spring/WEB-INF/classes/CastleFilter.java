//@UTF-8 CastleFilter.java
/*
 * Castle: KISA Web Attack Defender - JSP Version
 * 
 * Author : hucho in codeone
 *
 * Last modified Jun 27 2014
 *
 * History:
 *     
 *     
 */
package castlejsp;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

import javax.servlet.*;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class CastleFilter implements Filter  {

	private castlejsp.CastlePolicy castlePolicy = null;
	private String castleBasePath="";
	private String castleRealPath="";
	private HttpServletRequest httpServletRequest = null;
	private HttpServletResponse httpServletResponse = null;
	
	public void init(FilterConfig filterConfig) throws ServletException {
		
		this.castleRealPath =  filterConfig.getInitParameter("CastleRealPath"); 
    }
    
	public void doFilter (ServletRequest request,  ServletResponse response, FilterChain chain)
	{	
		try
		{
			this.httpServletRequest = (HttpServletRequest) request;		
			
			//this.writeLog(this.castleJSPVersionBaseDir);
			this.doRefereeLog("doFilter Start " );
			//String[] paths = this.castleRealPath.split(",");
			//this.castleRealPath = paths[0];
			//this.castleBasePath = paths[1];
			//this.writeLog("CastleBasePath : " + this.castleBasePath);
			this.writeLog("CastleRealPath : " + this.castleRealPath);
			String policyFile = this.castleRealPath+"\\castle_policy.xml";
			this.castlePolicy = new castlejsp.CastlePolicy(policyFile);
			if(this.castlePolicy != null) {
				//writeLog("Within Castle Filter ... ");
			  	boolean isPass = this.doReferee(this.httpServletRequest);
			  	if(!isPass){
			  		this.httpServletResponse = (HttpServletResponse)response;
			  		this.writeLog("CastleBasePath : " + this.castleBasePath);
			  		this.httpServletResponse.sendRedirect("/HellowProject/castle-jsp/error.jsp");
			  		return;
			  	}
			  	//this.httpServletResponse.sendError(HttpServletResponse.SC_BAD_REQUEST, "Bad Request !!!");
			  	//System.out.println ("CastleFilter : " + strServerName+strServletName );				
			}else{
				this.doRefereeLog("castlePolicy is null");
			}			
			chain.doFilter (request, response);			
		} catch (IOException io) {
			this.doRefereeLog("doFilter IO Exception " + io.getMessage() );
			//System.out.println ("IOException raised in CastleFilter" + io.getMessage());
		} catch (ServletException se) {
			this.doRefereeLog("doFilter Servlet Exception " + se.getMessage() );
			//System.out.println ("ServletException raised in CastleFilter" +se.getMessage());
		} catch (Exception e){
			this.doRefereeLog("doFilter Exception " + e.getStackTrace() );
			//System.out.println ("Exception raised in CastleFilter" + e.getMessage());
		}		
	}
	
	public void destroy() {
        // 
     }

	 public void doRefereeLog(String msg)  {
		 try{
		 this.writeLog("log test : " + msg +" \\n" );
		 }catch(Exception ex){

		 }
	 }
		
	private boolean doReferee(ServletRequest request) throws Exception  {
		//try
		//{		
			boolean isPass = true;
			//System.out.print ("Within SafeCode Engine ... ");
		  	this.httpServletRequest = (HttpServletRequest) request;
			/* Referee 생성 */
		  	String strServerName = new String(this.httpServletRequest.getServerName());
			String strServletName = new String(this.httpServletRequest.getServletPath());
			/** Create Referee **/
			
			castlejsp.CastleReferee castleReferee = new castlejsp.CastleReferee(this.castlePolicy, strServerName, strServletName, this.castleBasePath); 
			String strCastleMode = new String(castlejsp.CastleLib.getBase64Decode(castlePolicy.strMode));
			
			/* Enforcing 및 Permissive 모드일 때만 동작 */
			if (!strCastleMode.equals("DISABLED")) {

				boolean bCastleStatus = false;

				String strCastleErrorMessage = "";
				String strCastleLogMessage = "";

				String strRemoteIP = request.getRemoteAddr();
				java.util.Date d = new java.util.Date(System.currentTimeMillis());
				String strLogTime = d.toString();
				String strLogPath = this.httpServletRequest.getServletPath();

				byte[] b;
				java.nio.charset.CharsetDecoder decoder = java.nio.charset.Charset.forName("UTF-8").newDecoder();
				String strLogBool = new String(castlejsp.CastleLib.getBase64Decode(castlePolicy.strLogBool));
				String strLogCharset = new String(castlejsp.CastleLib.getBase64Decode(castlePolicy.strLogCharset));

				String strCastleLogPrefix = strRemoteIP + " - [" + strLogTime + "] " + strLogPath + ": ";

				/* 사이트 접근 통제 적용 */
				if (castleReferee.checkSitePolicy()) {

					strCastleErrorMessage = castleReferee.getErrorMessage();

					if (strLogBool.equals("TRUE")) {

						strCastleLogMessage = strCastleLogPrefix + castleReferee.getLogMessage();
						if (strLogCharset.equals("eucKR")) {

							b = strCastleLogMessage.getBytes("UTF-8");
							try {
								java.nio.CharBuffer r = decoder.decode(java.nio.ByteBuffer.wrap(b));
							} catch (java.nio.charset.CharacterCodingException e) {
								strCastleLogMessage = new String(b, "eucKR");
							}
						}
						
						this.writeLog(strCastleLogMessage);
					}

					bCastleStatus = true;

				}

					/* IP 접근 통제 적용 */
				String strCastleIPBool = new String(castlejsp.CastleLib.getBase64Decode(castlePolicy.strIPBool));

				if (strCastleIPBool.equals("TRUE")) {

					if (castleReferee.checkIPPolicy(strRemoteIP)) {

						strCastleErrorMessage = castleReferee.getErrorMessage();

						if (strLogBool.equals("TRUE")) {

							strCastleLogMessage = strCastleLogPrefix + castleReferee.getLogMessage();
							if (strLogCharset.equals("eucKR")) {

								b = strCastleLogMessage.getBytes("UTF-8");
								try {
									java.nio.CharBuffer r = decoder.decode(java.nio.ByteBuffer.wrap(b));
								} catch (java.nio.charset.CharacterCodingException e) {
									strCastleLogMessage = new String(b, "eucKR");
								}
							}
							this.writeLog(strCastleLogMessage);
						}
						bCastleStatus = true;
					}
				}

				/* GET/POST 변수 적용 */
				String strCastleTargetParamBool = new String(castlejsp.CastleLib.getBase64Decode(castlePolicy.strTargetParam));

				if (strCastleTargetParamBool.equals("TRUE")) {

					java.util.Enumeration eCastleParams = request.getParameterNames();
					while (eCastleParams.hasMoreElements()) {

						String strCastleParamName = (String)eCastleParams.nextElement();
						String strCastleParamValue = request.getParameter(strCastleParamName);
						String strCastleSiteCharset = "";

						strCastleParamValue = castleReferee.deleteDirectoryTraverse(strCastleParamValue);
						
						b = strCastleParamValue.getBytes("8859_1");
						try {
							java.nio.CharBuffer r = decoder.decode(java.nio.ByteBuffer.wrap(b));
							strCastleParamValue = r.toString();
							strCastleSiteCharset = "UTF-8";
						} catch (java.nio.charset.CharacterCodingException e) {
							strCastleParamValue = new String(b, "eucKR"); 
							strCastleSiteCharset = "eucKR";
						}
						this.writeLog("GET/POST Check : "+ strLogBool +":" +strCastleParamName +":" + strCastleParamValue );
						
						if (castleReferee.checkParamPolicy(strCastleParamName, strCastleParamValue, strCastleSiteCharset)) {
							this.writeLog("GET/POST Detected : "+ strLogBool +":" +strCastleParamName +":" + strCastleParamValue );
							strCastleErrorMessage = castleReferee.getErrorMessage();
							this.writeLog("GET/POST Check : strCastleLogMessage "+ strCastleErrorMessage );
							if (strLogBool.equals("TRUE")) {

								strCastleLogMessage = strCastleLogPrefix + castleReferee.getLogMessage();
								
								if (strLogCharset.equals("eucKR")) {
									
									b = strCastleLogMessage.getBytes("UTF-8");
									try {
										java.nio.CharBuffer r = decoder.decode(java.nio.ByteBuffer.wrap(b));
									} catch (java.nio.charset.CharacterCodingException e) {
										strCastleLogMessage = new String(b, "eucKR");
									}

								}

								this.writeLog(strCastleLogMessage);
							}

							bCastleStatus = true;

						}

					}

				}

				/* COOKIE 변수 적용 */
				String strCastleTargetCookieBool = new String(castlejsp.CastleLib.getBase64Decode(castlePolicy.strTargetCookie));

				if (strCastleTargetCookieBool.equals("TRUE")) {

					int i;
					Cookie[] castleCookies = this.httpServletRequest.getCookies();

					if (castleCookies != null) {

						for (i = 0; i < castleCookies.length; i++) {

							String strCastleCookieName = castleCookies[i].getName();
							String strCastleCookieValue = castleCookies[i].getValue();
							String strCastleSiteCharset = "";

							strCastleCookieValue = castleReferee.deleteDirectoryTraverse(strCastleCookieValue);

							b = strCastleCookieValue.getBytes("8859_1");
							try {
								java.nio.CharBuffer r = decoder.decode(java.nio.ByteBuffer.wrap(b));
								strCastleCookieValue = r.toString();
								strCastleSiteCharset = "UTF-8";
							} catch (java.nio.charset.CharacterCodingException e) {
								strCastleCookieValue = new String(b, "eucKR"); 
								strCastleSiteCharset = "eucKR";
							}

							if (castleReferee.checkCookiePolicy(strCastleCookieName, strCastleCookieValue, strCastleSiteCharset)) {

								strCastleErrorMessage = castleReferee.getErrorMessage();
								
								if (strLogBool.equals("TRUE")) {

									strCastleLogMessage = strCastleLogPrefix + castleReferee.getLogMessage();
									if (strLogCharset.equals("eucKR")) {
									
										b = strCastleLogMessage.getBytes("UTF-8");
										try {
											java.nio.CharBuffer r = decoder.decode(java.nio.ByteBuffer.wrap(b));
										} catch (java.nio.charset.CharacterCodingException e) {
											strCastleLogMessage = new String(b, "eucKR");
										}
									}

									this.writeLog(strCastleLogMessage);
								}
								bCastleStatus = true;
							}

						}

					}

				}
				this.writeLog("MODE : "+ strCastleMode );
					/* Enforcing 모드 */
				if (strCastleMode.equals("ENFORCING")) {
					this.writeLog("ENFORCING : "+ bCastleStatus );
						/* 결과 적용 */
					if (bCastleStatus) {
						//System.out.println(strCastleErrorMessage);						
						isPass = false;
					}
				}
					/* Permissive 모드 - Do not enforce */
			}
				/* Disabled 모드 - Nothing Todo */
			//chain.doFilter (request, response);		
			
		//} catch (IOException io) {
		//	System.out.println ("IOException raised in CastleFilter" + io.getMessage());
		//} catch (ServletException se) {
		//	System.out.println ("ServletException raised in CastleFilter" +se.getMessage());
		//} catch (Exception e){
		//	System.out.println ("Exception raised in CastleFilter" + e.getMessage());
		//}			
		return isPass;

	}
	
	
	private ServletContext getServletContext()
	{
		return this.httpServletRequest.getSession().getServletContext();
	}
	
	private void writeLog(String log) throws Exception {
		String strLogFileName = "castle_log.txt";//new String(castlejsp.CastleLib.getBase64Decode(castlePolicy.strLogFileName));

		java.text.SimpleDateFormat fm = new java.text.SimpleDateFormat("yyyyMMdd");
		String strCastleToday = fm.format(new java.util.Date());
		
		
		String strCastleLogPath = "D:\\xampp\\tomcat\\webapps\\HellowProject\\castle-jsp\\";
		//strCastleLogPath = this.getServletContext().getRealPath(castleJSPVersionBaseDir);
		String strCastleLogFile = strCastleLogPath + "\\log\\" + strCastleToday + "-" + strLogFileName;
		java.io.File f = new java.io.File(strCastleLogFile);
		if (!f.exists()) {
			if (!f.createNewFile()) {
				System.out.println(castlejsp.CastleLib.msgBack("CASTLE - 로그 파일을 생성할 수 없습니다."));
				return;
			}
		}

		f = new java.io.File(strCastleLogFile);
		
		if (!f.canWrite()) {
			System.out.println(castlejsp.CastleLib.msgBack("CASTLE - 로그 파일을 쓸수 없습니다."));
			return;
		}
		BufferedWriter fw = new BufferedWriter( new FileWriter(strCastleLogFile,true)); 
		fw.write(log +"\n"); 
		fw.flush(); 
		fw.close();   
	}
	
	private void setPolicy(){
		castlePolicy.listSQLInjection = new java.util.Vector();

	    castlePolicy.listSQLInjection.add("ZGVsZXRlICtmcm9t");
	    castlePolicy.listSQLInjection.add("ZHJvcCArZGF0YWJhc2U=");
	    castlePolicy.listSQLInjection.add("ZHJvcCArdGFibGU=");
	    castlePolicy.listSQLInjection.add("ZHJvcCArY29sdW1u");
	    castlePolicy.listSQLInjection.add("ZHJvcCArcHJvY2VkdXJl");
	    castlePolicy.listSQLInjection.add("Y3JlYXRlICt0YWJsZQ==");
	    castlePolicy.listSQLInjection.add("dXBkYXRlXHMrLio/c2V0");
	    castlePolicy.listSQLInjection.add("aW5zZXJ0XHMraW50by4qP3ZhbHVlcw==");
	    castlePolicy.listSQLInjection.add("c2VsZWN0XHMrLio/ZnJvbQ==");
	    castlePolicy.listSQLInjection.add("YnVsayAraW5zZXJ0");
	    castlePolicy.listSQLInjection.add("dW5pb24gK3NlbGVjdA==");
	    castlePolicy.listSQLInjection.add("b3JccytbJyJcc10qXHcrWyciXHNdKlxzKj1ccypbJyJcc10qXHcr");
	    castlePolicy.listSQLInjection.add("YWx0ZXIgK3RhYmxl");
	    castlePolicy.listSQLInjection.add("aW50byArb3V0ZmlsZQ==");
	    castlePolicy.listSQLInjection.add("bG9hZCArZGF0YQ==");
	    castlePolicy.listSQLInjection.add("ZGVjbGFyZS4rP3ZhcmNoYXIuKz9zZXQ=");


	    castlePolicy.listXSS = new java.util.Vector();

	    castlePolicy.listXSS.add("PHNjcmlwdA==");
	    castlePolicy.listXSS.add("amF2YXNjcmlwdDo=");
	    castlePolicy.listXSS.add("JTNjc2NyaXB0");
	    castlePolicy.listXSS.add("c2NyaXB0Lis/c3JjXHMqPQ==");
	    castlePolicy.listXSS.add("JiN4M2M7c2NyaXB0");
	    castlePolicy.listXSS.add("ZXhwcmVzc2lvblxzKlwo");
	    castlePolicy.listXSS.add("eHNzOi4qXCg=");
	    castlePolicy.listXSS.add("ZG9jdW1lbnRcLmNvb2tpZQ==");
	    castlePolicy.listXSS.add("ZG9jdW1lbnRcLmxvY2F0aW9u");
	    castlePolicy.listXSS.add("ZG9jdW1lbnRcLndyaXRl");
	    castlePolicy.listXSS.add("b25BYm9ydCAqPQ==");
	    castlePolicy.listXSS.add("b25CbHVyICo9");
	    castlePolicy.listXSS.add("b25DaGFuZ2UgKj0=");
	    castlePolicy.listXSS.add("b25DbGljayAqPQ==");
	    castlePolicy.listXSS.add("b25EYmxDbGljayAqPQ==");
	    castlePolicy.listXSS.add("b25EcmFnRHJvcCAqPQ==");
	    castlePolicy.listXSS.add("b25FcnJvciAqPQ==");
	    castlePolicy.listXSS.add("b25Gb2N1cyAqPQ==");
	    castlePolicy.listXSS.add("b25LZXlEb3duICo9");
	    castlePolicy.listXSS.add("b25LZXlQcmVzcyAqPQ==");
	    castlePolicy.listXSS.add("b25LZXlVcCAqPQ==");
	    castlePolicy.listXSS.add("b25sb2FkICo9");
	    castlePolicy.listXSS.add("b25tb3VzZWRvd24gKj0=");
	    castlePolicy.listXSS.add("b25tb3VzZW1vdmUgKj0=");
	    castlePolicy.listXSS.add("b25tb3VzZW91dCAqPQ==");
	    castlePolicy.listXSS.add("b25tb3VzZW92ZXIgKj0=");
	    castlePolicy.listXSS.add("b25tb3VzZXVwICo9");
	    castlePolicy.listXSS.add("b25tb3ZlICo9");
	    castlePolicy.listXSS.add("b25yZXNldCAqPQ==");
	    castlePolicy.listXSS.add("b25yZXNpemUgKj0=");
	    castlePolicy.listXSS.add("b25zZWxlY3QgKj0=");
	    castlePolicy.listXSS.add("b25zdWJtaXQgKj0=");
	    castlePolicy.listXSS.add("b251bmxvYWQgKj0=");
	    castlePolicy.listXSS.add("bG9jYXRpb24uaHJlZiAqPQ==");


	    castlePolicy.listWord = new java.util.Vector();

	    castlePolicy.listWord.add("u/Wzog==");
	    castlePolicy.listWord.add("sLO79bOi");
	    castlePolicy.listWord.add("vNK79bOi");
	    castlePolicy.listWord.add("urS9xQ==");
	    castlePolicy.listWord.add("wfa29g==");
	    castlePolicy.listWord.add("vr7GyA==");
	    castlePolicy.listWord.add("vcrGyA==");
	    castlePolicy.listWord.add("tM+x4rnM");
	    castlePolicy.listWord.add("wu629g==");
	    castlePolicy.listWord.add("vdaz4g==");
	    castlePolicy.listWord.add("vdaz8A==");
	    castlePolicy.listWord.add("uvm9xQ==");
	    castlePolicy.listWord.add("wb+x7g==");
	    castlePolicy.listWord.add("tM+x4rnM");
	    castlePolicy.listWord.add("wb+wsMC6sNQ=");
	    castlePolicy.listWord.add("wOKz8A==");
	    castlePolicy.listWord.add("uq2++73F");
	    castlePolicy.listWord.add("udm6uLv1s6I=");
	    castlePolicy.listWord.add("vsO79bOi");
	    castlePolicy.listWord.add("vr653w==");
	    castlePolicy.listWord.add("vr7GyA==");
	    castlePolicy.listWord.add("vcO5+g==");
	    castlePolicy.listWord.add("vr65+g==");
	    castlePolicy.listWord.add("trCx17b2");
	    castlePolicy.listWord.add("wb+55A==");
	    castlePolicy.listWord.add("w9/DtcDO");
	    castlePolicy.listWord.add("w9/DtWlk");
	    castlePolicy.listWord.add("w9/Dtb7GwMy18A==");
	    castlePolicy.listWord.add("w98vw7UvwM4=");
	    castlePolicy.listWord.add("vabAzA==");
	    castlePolicy.listWord.add("te69xQ==");
	    castlePolicy.listWord.add("vc6wocH2");
	    castlePolicy.listWord.add("uczEo7Pw");
	    castlePolicy.listWord.add("uczEo7PR");
	    castlePolicy.listWord.add("wu629g==");
	    castlePolicy.listWord.add("wde9wLTPtNk=");
	    castlePolicy.listWord.add("vsa01LXpvsY=");
	    castlePolicy.listWord.add("vr6567PR");
	    castlePolicy.listWord.add("c2V4");
	    castlePolicy.listWord.add("vL29ug==");
	    castlePolicy.listWord.add("udnEq7bz");


	    castlePolicy.listTag = new java.util.Vector();

	    castlePolicy.listTag.add("PGlmcmFtZSAq");
	    castlePolicy.listTag.add("PG1ldGEgKg==");
	    castlePolicy.listTag.add("XC5cLi8=");
	    castlePolicy.listTag.add("XC5cLlxc");


	    castlePolicy.listIP = new java.util.Vector();


	    castlePolicy.strAdminModuleName = "Q0FTVExFIC0gSlNQILn2wPw=";
	    castlePolicy.strAdminID = "YWRtaW4=";
	    castlePolicy.strAdminPassword = "ZTFhYTVmZDYyNGFhZjJjYzdjZWZlYWU1MjNhYmJiNw==";
	    castlePolicy.strAdminLastModified = "V2VkIEp1biAyNSAxMToyNzo0MSBLU1QgMjAxNA==";

	    castlePolicy.strSiteBool = "VFJVRQ==";
	    castlePolicy.strMode = "UEVSTUlTU0lWRQ==";
	    castlePolicy.strAlert = "U1RFQUxUSA==";

	    castlePolicy.strLogBool = "VFJVRQ==";
	    castlePolicy.strLogDegree = "U0lNUExF";
	    castlePolicy.strLogFileName = "Y2FzdGxlX2xvZy5sb2c=";
	    castlePolicy.strLogCharset = "VVRGLTg=";
	    castlePolicy.strLogListCount = "MTA=";

	    castlePolicy.strTargetParam = "VFJVRQ==";
	    castlePolicy.strTargetCookie = "VFJVRQ==";

	    castlePolicy.strSQLInjectionBool = "VFJVRQ==";
	    castlePolicy.strXSSBool = "VFJVRQ==";
	    castlePolicy.strWordBool = "RkFMU0U=";
	    castlePolicy.strTagBool = "VFJVRQ==";
	    castlePolicy.strIPBool = "RkFMU0U=";

	    castlePolicy.strIPBase = "REVOWQ==";
	}
}
