package castlejsp;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.HashSet;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;


import java.io.*;
import org.w3c.dom.*;
import org.xml.sax.SAXException;
//import org.w3c.dom.Element;
//import org.w3c.dom.Node;
//import org.w3c.dom.NodeList;

public class CastleXml {

	private static CastleXml instance = null;
	private Document xmlDoc = null;
	private String xmlFile =  "";
	private Long lastModifed = (long)0;	
	
	private DocumentBuilderFactory factory = null;
	private DocumentBuilder docBuilder = null;
	private Element rootElement= null;
	
	public long getLastModified()
	{
		return this.lastModifed;
	}
			
	public boolean isAvailable = false;
	
	public synchronized static CastleXml getInstance(String fileName)
	{
		if (instance == null)
		{
			instance = new CastleXml(fileName);
		}
		return instance;
	}
	
	public CastleXml(){	}
	
	public CastleXml(String fileName)
	{
		this.setXmlFile(fileName);
		if (factory == null){
			factory = DocumentBuilderFactory.newInstance();
			this.config();
			
		}		
	}

	public void setXmlFile(String file)
	{
		this.xmlFile = file;
	}
	
	/* (non-Javadoc)
	 * @see codeone.SafeCodeConfig#load()
	 */
	public boolean config()
	{
		boolean flag = false;
		try{
			// root elements
			docBuilder = factory.newDocumentBuilder();			
			File f = new File(this.xmlFile);
			if(f.exists()){
				this.lastModifed = f.lastModified();
				flag = true;
				this.isAvailable = true;
				this.load();
			}			
		}catch(ParserConfigurationException ex)
		{			
			this.isAvailable = false;
		}
		return true;
	}
	
	public void create(String rootName)
	{		
		this.xmlDoc = docBuilder.newDocument();
		this.rootElement = this.xmlDoc.createElement(rootName);
		this.rootElement.appendChild(rootElement);
	}
	
	public Element getRoot()
	{
		return this.rootElement;
	}
	
	public void load() {		
		// TODO Auto-generated method stub
		if(this.isAvailable){
			try {
				this.xmlDoc = docBuilder.parse(this.xmlFile);
				//xmlDoc.getDocumentElement().normalize();
				this.isAvailable = true;
			} catch (SAXException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				this.isAvailable = false;
			}catch(IOException ex){
				this.isAvailable = false;
			}				
		}
	}

	/* (non-Javadoc)
	 * @see codeone.SafeCodeConfig#save()
	 */

	public boolean save() {
		// TODO Auto-generated method stub
		boolean flag = true;
		if(!this.xmlFile.equals("")){
			try{
				TransformerFactory transformerFactory = TransformerFactory.newInstance();
				Transformer transformer = transformerFactory.newTransformer();
				DOMSource source = new DOMSource(this.xmlDoc);
				StreamResult result = new StreamResult(new File(this.xmlFile));
				// Output to console for testing
				// StreamResult result = new StreamResult(System.out);
				transformer.transform(source, result);
			} catch (TransformerException tfe) {
				flag = false;
				tfe.printStackTrace();
			}
		}else{
			flag = false;
			System.out.println("Thre is no xml file name!");
		}	
		return flag;
	}
	
	public Element getRootNode()
	{
		return this.xmlDoc.getDocumentElement();
	}

	
	public void insert(String nodeName, HashMap value) {
		// TODO Auto-generated method stub

	}
	
	public void insert(String parentName, String nodeName, HashSet value) {
		// TODO Auto-generated method stub

	}

	/* (non-Javadoc)
	 * @see codeone.SafeCodeConfig#delete()
	 */

	public void delete(String nodeName) {
		// TODO Auto-generated method stub

	}

	/* (non-Javadoc)
	 * @see codeone.SafeCodeConfig#update()
	 */

	public void update() {
		// TODO Auto-generated method stub

	}
	
	public boolean findSection(String name)
	{
		boolean flag = false;
		
		return flag;
	}


	public void getConfig(String name) {
		// TODO Auto-generated method stub
		
		//NodeList retNode = null;
		Element root = this.xmlDoc.getDocumentElement();
		
		//Node rootnode = nodechange(root.getChildNodes());
		//NodeList rootList = root.getChildNodes();;
		NodeList rootList = root.getElementsByTagName(name);
		
		int rootsize = rootList.getLength();
		//config Setting
		for(int i = 0;i<rootsize;i++){
			if(rootList.item(i).getNodeName().equals(name))
			{	
				Node node = rootList.item(i);
				System.out.println(node.getNodeName() + ":" + node.getNodeValue());
				NodeList childList = ((Element)node).getChildNodes();
				int childSize = childList.getLength();
				for(int j = 0; j<childSize; j++){
					Node node2 = childList.item(j);
					if(node2.getNodeType() == Node.ELEMENT_NODE){
						System.out.println(node2.getNodeName() + ":" + node2.getTextContent());
					}
				}
			}
		}
		//return rootList;
	}

	public void setConfig(String section, Node node) {
		// TODO Auto-generated method stub
		
	}
}
