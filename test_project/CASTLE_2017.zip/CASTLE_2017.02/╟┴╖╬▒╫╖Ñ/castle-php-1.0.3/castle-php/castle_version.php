<?php
define("CASTLE_VERSION", "1.0.3");
?>
