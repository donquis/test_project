<?php 

//@UTF-8 castle_admin_bottom.php
/*
 * Castle: KISA Web Attack Defender - PHP Version
 * 
 * Author : 이재서 <mirr1004@gmail.com>
 *          주필환 <juluxer@gmail.com>
 *
 * Last modified Sep 18 2008
 *
 */
?>
                <div style=height:15pt>※ CASTLE과 관련된 문의 사항은 <b>castle@krcert.or.kr</b>로 하십시오.</div>
                <div style=height:11pt>서울시 송파구 가락동 78번지 IT벤처타워 Tel. 02-405-5617</div>
                <div style=height:10pt>Copyright(c) 2009 Korea Information Security Agency. All right reserved.</div>
